import { useEffect, useRef, useState } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";

const links = [
  { label: "Features", href: "/#features" },
  { label: "How it works", href: "/#how-it-works" },
  { label: "Templates", href: "/#templates" },
  { label: "Explore", href: "/explore" },
  { label: "Pricing", href: "/pricing" },
] as const;

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLButtonElement>(null);
  const mobileRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!open) return;
    const priorOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    mobileRef.current?.querySelector<HTMLAnchorElement>("a[href]")?.focus();
    function keydown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setOpen(false);
        menuRef.current?.focus();
      }
      if (event.key !== "Tab" || !mobileRef.current) return;
      const items = Array.from(mobileRef.current.querySelectorAll<HTMLAnchorElement>("a[href]"));
      if (!items.length) return;
      // The menu button remains in the tab sequence, and the focus cycle includes it.
      const order: HTMLElement[] = [menuRef.current, ...items].filter((item): item is HTMLElement => Boolean(item));
      const start = order[0], end = order[order.length - 1];
      if (event.shiftKey && document.activeElement === start && end) { event.preventDefault(); end.focus(); }
      else if (!event.shiftKey && document.activeElement === end && start) { event.preventDefault(); start.focus(); }
    }
    document.addEventListener("keydown", keydown);
    return () => { document.body.style.overflow = priorOverflow; document.removeEventListener("keydown", keydown); };
  }, [open]);

  function closeMenu() { setOpen(false); }

  return (
    <header className="hb-header">
      <div className="hb-header__inner">
        <a href="/" className="hb-header__logo" aria-label="HEYBIO homepage" onClick={closeMenu}>HEYBIO<span aria-hidden="true">↗</span></a>
        <nav className="hb-header__desktop" aria-label="Primary navigation">
          {links.map(({ label, href }) => <a href={href} key={href}>{label}</a>)}
        </nav>
        <div className="hb-header__actions">
          <a href="/login" className="hb-header__login">Log in</a>
          <a href="/#claim-username" className="hb-header__create">Get started <ArrowUpRight size={17} aria-hidden="true"/></a>
          <button ref={menuRef} type="button" className="hb-header__menu" aria-label={open ? "Close navigation menu" : "Open navigation menu"} aria-expanded={open} aria-controls="hb-mobile-nav" onClick={() => setOpen((wasOpen) => !wasOpen)}>
            {open ? <X size={22} aria-hidden="true"/> : <Menu size={22} aria-hidden="true"/>}
          </button>
        </div>
      </div>
      <nav ref={mobileRef} id="hb-mobile-nav" className={open ? "hb-header__mobile hb-header__mobile--open" : "hb-header__mobile"} aria-label="Mobile navigation" hidden={!open}>
        {links.map(({ label, href }, index) => <a key={href} href={href} onClick={closeMenu}><span>{String(index + 1).padStart(2, "0")}</span>{label}<ArrowUpRight size={18} aria-hidden="true"/></a>)}
        <a href="/login" onClick={closeMenu}><span>06</span>Log in<ArrowUpRight size={18} aria-hidden="true"/></a>
        <a className="hb-header__mobile-cta" href="/#claim-username" onClick={closeMenu}>Create your HEYBIO ↗</a>
      </nav>
    </header>
  );
}
