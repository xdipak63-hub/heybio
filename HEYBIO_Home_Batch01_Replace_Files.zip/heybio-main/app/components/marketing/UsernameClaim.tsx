import { useEffect, useId, useState } from "react";
import { useNavigate } from "react-router";
import { ArrowUpRight, Check, LoaderCircle } from "lucide-react";

type Availability = { available: boolean; message: string; checkedUsername: string };
const VALID_USERNAME = /^[a-z][a-z0-9_]{2,29}$/;
const RESERVED = new Set([
  "admin", "administrator", "api", "app", "auth", "billing", "callback", "contact", "dashboard",
  "dipolabs", "dipo_labs", "explore", "features", "forgot-password", "heybio", "help",
  "hypedrop", "login", "logout", "me", "news", "onboarding", "official", "pricing", "privacy",
  "register", "reset-password", "root", "security", "settings", "signup", "staff", "support",
  "system", "templates", "terms", "verify-email", "www", "our-story", "about-heybio", "about-dipolabs",
  "whats-new", "report-problem", "getting-started", "faqs", "cookie-policy", "refund-policy",
]);

export default function UsernameClaim() {
  const navigate = useNavigate();
  const inputId = useId();
  const feedbackId = useId();
  const [username, setUsername] = useState("");
  const [availability, setAvailability] = useState<Availability | null>(null);
  const [checking, setChecking] = useState(false);
  const name = username.trim().toLowerCase();
  const valid = VALID_USERNAME.test(name) && !RESERVED.has(name);

  useEffect(() => {
    setAvailability(null);
    if (!valid) { setChecking(false); return; }

    const controller = new AbortController();
    let active = true;
    setChecking(true);
    const timer = window.setTimeout(async () => {
      try {
        const response = await fetch(`/api/username-availability?username=${encodeURIComponent(name)}`, {
          signal: controller.signal, headers: { Accept: "application/json" },
        });
        if (!response.ok) throw new Error("Availability check unavailable");
        const result: Availability = await response.json();
        if (active) setAvailability({ ...result, checkedUsername: name });
      } catch (error) {
        if (active && !(error instanceof Error && error.name === "AbortError")) {
          setAvailability({ available: false, message: "Can't check this name right now. Please try again.", checkedUsername: name });
        }
      } finally { if (active) setChecking(false); }
    }, 350);
    return () => { active = false; window.clearTimeout(timer); controller.abort(); };
  }, [name, valid]);

  const canContinue = valid && availability?.checkedUsername === name && availability.available === true && !checking;
  function claim(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canContinue) return;
    try { window.sessionStorage.setItem("heybio:desired-username", name); } catch { /* Query string fallback. */ }
    navigate(`/signup?username=${encodeURIComponent(name)}`);
  }

  const message = name.length > 0 && !valid
    ? "3–30 characters, starting with a letter. Use letters, numbers and underscores."
    : checking ? "Checking this username…" : availability?.message ?? "Start with a username that feels like you.";

  return (
    <form className="hx-claim" onSubmit={claim} noValidate>
      <label className="hx-claim__label" htmlFor={inputId}>Claim your own corner of the internet</label>
      <div className="hx-claim__row">
        <div className="hx-claim__input-wrap">
          <span className="hx-claim__prefix" aria-hidden="true">heybio.in/</span>
          <input id={inputId} type="text" name="username" inputMode="text" autoComplete="off" autoCapitalize="off" spellCheck={false}
            placeholder="yourname" value={username} minLength={3} maxLength={30} required aria-describedby={feedbackId}
            aria-invalid={name.length > 0 && !valid}
            onChange={(event) => setUsername(event.target.value.toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 30))}/>
          {checking ? <LoaderCircle size={18} className="hx-claim__spin" aria-label="Checking"/> : canContinue ? <Check size={18} className="hx-claim__tick" aria-label="Available"/> : null}
        </div>
        <button type="submit" disabled={!canContinue} className="hx-claim__button">Claim my HEYBIO <ArrowUpRight size={18} aria-hidden="true"/></button>
      </div>
      <p id={feedbackId} role="status" aria-live="polite" className={`hx-claim__feedback ${canContinue ? "hx-claim__feedback--ok" : ""}`}>{message}</p>
    </form>
  );
}
