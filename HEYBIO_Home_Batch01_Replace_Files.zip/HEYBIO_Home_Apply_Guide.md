# HEYBIO ↗ — Premium Homepage Replacement (Batch 01)

**Source:** user-provided `heybio-main(4).zip`.

## Apply carefully
1. Back up your repository and current deployed database before replacing files.
2. Copy each listed file into the project **at the same relative path**. New files are `app/components/marketing/HomeExperience.tsx` and `app/styles/heybio-home.css`.
3. Do **not** overwrite SQL migrations, admin roles, billing data, or auth secrets from this ZIP. They are intentionally untouched.
4. Confirm Cloudflare `SUPABASE_URL` and server-secret `SUPABASE_SERVICE_ROLE_KEY` exist; the availability endpoint uses this server-only key to bypass owner-only profile RLS. **Never publish it through client-side environment variables**.
5. Install dependencies using `npm ci`, run `npm run typecheck`, then `npm run build`, then browser-test the site and public profile. Those commands were not successfully verified in the audit container due incomplete dependency installation.
6. Test homepage at mobile 320/375/430px and desktop widths, navigation, username availability, signup flow and login. The user name is saved in session storage and onboarding still reads `heybio:desired-username`.

## What is fixed/added
- Entirely new clean product-first homepage: clear hero, live username validation, beautiful *illustrative* creator profile, link-flow story, four steps, helpful pinned notes, functional template-demo switcher, honest trust section, distinctive separate HYPE DROP introduction, accessible FAQs and final CTA.
- Pricing plan cards removed from homepage. Dedicated `/pricing` route remains available.
- Published marketing routes registered (features, explore, templates, news, about, contact). Empty legal/admin/dashboard routes are **not** registered as fake pages.
- Missing `normalizeExternalUrl` export supplied for link validation.
- Username availability lookup now uses server-only service role to avoid false-available results caused by owner-only RLS, and checks `reserved_usernames` as well; it also invokes the Cloudflare rate-limiter binding if present (configure it for production).
- New CSS scoped to `.hx-home`; existing dashboard and public profile styling not deliberately changed.
- CSS reduced-motion support; scroll reveal only animates content once and never hides content by default.

## Known unresolved blockers — NOT launch-ready
- Supabase migration files 002/004/005 reference `profiles.is_published` and `profiles.is_suspended`, which are not created by 001; production-safe SQL fixes depend on knowing migration history.
- Two migrations share version 023. Do not rename if one or both were previously applied without checking Supabase migration history.
- Missing legal docs, many creator dashboard pages and admin pages remain incomplete/empty.
- End-to-end tests for Razorpay, Supabase SSR MFA, HYPE DROP cross-product authorization and complete public avatar/social integration were not run.
- Full build and typecheck could not run in current environment: `npm ci` incomplete (dependencies such as react-router CLI and @types were missing). Static checks only: 180 TS/TSX parses and relative paths, no parser/import-path errors.
- The visual profile is a labeled *example*, not a real creator endorsement. Real ratings, testimonials, metrics and guarantees are deliberately omitted.

## File paths supplied
1. `app/routes/marketing/home.tsx`
2. `app/components/marketing/Navbar.tsx`
3. `app/components/marketing/Hero.tsx`
4. `app/components/marketing/UsernameClaim.tsx`
5. `app/components/marketing/HomeExperience.tsx`
6. `app/components/marketing/HypeDropSection.tsx`
7. `app/components/marketing/FAQSection.tsx`
8. `app/components/marketing/FinalCTA.tsx`
9. `app/styles/heybio-home.css`
10. `app/lib/security/safe-redirect.ts`
11. `app/routes/api/username-availability.ts`
12. `app/routes.ts`

## Full source

All files are individually present in the ZIP at their exact paths. A separate Markdown source-code book is also provided for copying files manually.
