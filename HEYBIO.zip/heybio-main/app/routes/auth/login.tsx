import { useState } from "react";
import {
  Form,
  Link,
  data,
  redirect,
  useActionData,
  useLoaderData,
  useNavigation,
  useSearchParams,
} from "react-router";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import TurnstileField from "../../components/auth/TurnstileField";
import {
  createSupabaseServer,
  requireSameOrigin,
} from "../../lib/supabase/server";
import {
  getTurnstileSiteKey,
  verifyTurnstile,
} from "../../lib/security/turnstile.server";

export function meta() {
  return [
    { title: "Log in — HEYBIO" },
    { name: "robots", content: "noindex, nofollow" },
  ];
}

export async function loader({ request, context }: LoaderFunctionArgs) {
  const { supabase, headers } = createSupabaseServer(request, context);
  const { data: { user } } = await supabase.auth.getUser();

  if (user?.email_confirmed_at) {
    throw redirect("/dashboard", { headers });
  }

  return data({ siteKey: getTurnstileSiteKey(context) }, { headers });
}

export async function action({ request, context }: ActionFunctionArgs) {
  requireSameOrigin(request);
  const { supabase, headers } = createSupabaseServer(request, context);
  const form = await request.formData();
  const intent = String(form.get("intent") ?? "email");
  const email = String(form.get("email") ?? "").trim().toLowerCase();
  const password = String(form.get("password") ?? "");

  function fail(error: string, status: 400 | 503 = 400) {
    return data({ error, retryKey: Date.now() }, { status, headers });
  }

  if (intent !== "email" && intent !== "google") {
    return fail("Invalid sign-in method.");
  }

  if (
    intent === "email" &&
    (!email || !password || email.length > 254 || password.length > 128)
  ) {
    return fail("Enter your email address and password.");
  }

  const check = await verifyTurnstile(
    request,
    context,
    String(form.get("cf-turnstile-response") ?? ""),
  );
  if (!check.ok) return fail(check.message, check.status);

  if (intent === "google") {
    const callback = new URL("/auth/callback", request.url);
    callback.searchParams.set("next", "/dashboard");
    const { data: oauth, error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: callback.toString() },
    });

    if (error || !oauth.url) {
      return fail("Google sign-in couldn't start. Please try again.", 503);
    }
    throw redirect(oauth.url, { headers });
  }

  const { error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) {
    return fail("Invalid credentials or the account isn't verified.");
  }

  throw redirect("/dashboard", { headers });
}

export default function LoginPage() {
  const { siteKey } = useLoaderData<typeof loader>();
  const result = useActionData<typeof action>();
  const navigation = useNavigation();
  const [params] = useSearchParams();
  const [verified, setVerified] = useState(false);
  const submitting = navigation.state === "submitting";

  return (
    <main className="auth-layout">
      <div className="auth-panel">
        <Link className="brand" to="/">
          HEYBIO<span className="brand-arrow">↗</span>
        </Link>

        <div className="auth-panel__content">
          <span className="eyebrow">WELCOME BACK</span>
          <h1>Your world awaits.</h1>
          <p>Log in to manage everything you share.</p>

          {params.get("verification") === "required" && (
            <div className="auth-notice" role="status">
              Please verify your email before continuing.
            </div>
          )}
          {params.get("verified") === "1" && (
            <div className="auth-notice" role="status">
              Email verification completed. You can now log in.
            </div>
          )}

          <Form method="post" className="auth-form">
            {result?.error && (
              <div className="auth-error" role="alert">{result.error}</div>
            )}

            <label>
              Email address
              <input
                type="email"
                name="email"
                autoComplete="email"
                required
                maxLength={254}
                placeholder="you@example.com"
              />
            </label>

            <label>
              Password
              <input
                type="password"
                name="password"
                autoComplete="current-password"
                required
                maxLength={128}
                placeholder="Enter your password"
              />
            </label>

            <TurnstileField
              siteKey={siteKey}
              retryKey={result?.retryKey}
              onVerifiedChange={setVerified}
            />

            <button
              type="submit"
              name="intent"
              value="email"
              disabled={submitting || !verified}
              className="button button--dark auth-submit"
            >
              {submitting ? "Please wait…" : "Log in ↗"}
            </button>

            <div className="hb-auth-divider">or</div>

            <button
              type="submit"
              name="intent"
              value="google"
              formNoValidate
              disabled={submitting || !verified}
              className="hb-auth-google"
            >
              <span aria-hidden="true">G</span>
              Continue with Google
            </button>

            <p className="hb-auth-form-note">
              A quick security check protects HEYBIO accounts from automated abuse.
            </p>
          </Form>

          <p className="auth-switch">
            <Link to="/forgot-password">Forgot password?</Link>
          </p>
          <p className="auth-switch">
            New to HEYBIO? <Link to="/signup">Create an account</Link>
          </p>
        </div>
      </div>

      <aside className="auth-visual">
        <span>HEYBIO BY DIPO LABS</span>
        <div>
          <span className="auth-visual__mark">↗</span>
          <h2>Your world.<br />One link.</h2>
          <p>Pick up right where you left off.</p>
        </div>
        <span>MADE FOR MORE</span>
      </aside>
    </main>
  );
}
