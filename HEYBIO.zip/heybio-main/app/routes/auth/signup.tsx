import { useState } from "react";
import {
  Form,
  Link,
  data,
  redirect,
  useActionData,
  useLoaderData,
  useNavigation,
} from "react-router";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import TurnstileField from "../../components/auth/TurnstileField";
import {
  createSupabaseServer,
  requireSameOrigin,
} from "../../lib/supabase/server";
import {
  getTurnstileSiteKey,
  verifyTurnstile,
} from "../../lib/security/turnstile.server";

export function meta() {
  return [
    { title: "Create account — HEYBIO" },
    { name: "robots", content: "noindex, nofollow" },
  ];
}

export async function loader({ request, context }: LoaderFunctionArgs) {
  const { supabase, headers } = createSupabaseServer(request, context);
  const { data: { user } } = await supabase.auth.getUser();

  if (user?.email_confirmed_at) {
    throw redirect("/onboarding/choose-username", { headers });
  }

  return data({ siteKey: getTurnstileSiteKey(context) }, { headers });
}

export async function action({ request, context }: ActionFunctionArgs) {
  requireSameOrigin(request);
  const { supabase, headers } = createSupabaseServer(request, context);
  const form = await request.formData();
  const intent = String(form.get("intent") ?? "email");
  const name = String(form.get("name") ?? "").trim();
  const email = String(form.get("email") ?? "").trim().toLowerCase();
  const password = String(form.get("password") ?? "");

  function fail(error: string, status: 400 | 503 = 400) {
    return data(
      { error, success: false, retryKey: Date.now() },
      { status, headers },
    );
  }

  if (intent !== "email" && intent !== "google") {
    return fail("Invalid sign-up method.");
  }

  if (intent === "email") {
    if (name.length < 2 || name.length > 80) {
      return fail("Enter a name between 2 and 80 characters.");
    }
    if (
      email.length > 254 ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
    ) {
      return fail("Enter a valid email address.");
    }
    if (password.length < 12 || password.length > 128) {
      return fail("Use a password between 12 and 128 characters.");
    }
  }

  const check = await verifyTurnstile(
    request,
    context,
    String(form.get("cf-turnstile-response") ?? ""),
  );
  if (!check.ok) return fail(check.message, check.status);

  const callback = new URL("/auth/callback", request.url);
  callback.searchParams.set("next", "/onboarding/choose-username");

  if (intent === "google") {
    const { data: oauth, error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: callback.toString() },
    });

    if (error || !oauth.url) {
      return fail("Google sign-up couldn't start. Please try again.", 503);
    }
    throw redirect(oauth.url, { headers });
  }

  const { data: result, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: callback.toString(),
      data: { display_name: name },
    },
  });

  if (error) {
    return fail(
      error.status === 429
        ? "Too many attempts. Please try again later."
        : "We couldn't complete signup. Please try again.",
    );
  }

  if (result.session) {
    throw redirect("/onboarding/choose-username", { headers });
  }

  return data(
    { error: null, success: true, retryKey: 0 },
    { headers },
  );
}

export default function SignupPage() {
  const { siteKey } = useLoaderData<typeof loader>();
  const result = useActionData<typeof action>();
  const navigation = useNavigation();
  const [verified, setVerified] = useState(false);
  const submitting = navigation.state === "submitting";

  return (
    <main className="auth-layout">
      <div className="auth-panel">
        <Link className="brand" to="/">
          HEYBIO<span className="brand-arrow">↗</span>
        </Link>

        <div className="auth-panel__content">
          <span className="eyebrow">YOUR WORLD STARTS HERE</span>
          <h1>Create your space.</h1>
          <p>Everything you are, everything you share. One beautiful home.</p>

          {result?.success ? (
            <div className="auth-notice" role="status">
              Check your email for the verification link. After confirming,
              you can set up your HEYBIO profile.
            </div>
          ) : (
            <Form method="post" className="auth-form">
              {result?.error && (
                <div className="auth-error" role="alert">{result.error}</div>
              )}

              <label>
                Your name
                <input
                  name="name"
                  type="text"
                  autoComplete="name"
                  minLength={2}
                  maxLength={80}
                  required
                  placeholder="What should we call you?"
                />
              </label>

              <label>
                Email address
                <input
                  name="email"
                  type="email"
                  autoComplete="email"
                  maxLength={254}
                  required
                  placeholder="you@example.com"
                />
              </label>

              <label>
                Password
                <input
                  name="password"
                  type="password"
                  autoComplete="new-password"
                  minLength={12}
                  maxLength={128}
                  required
                  placeholder="At least 12 characters"
                />
              </label>

              <TurnstileField
                siteKey={siteKey}
                retryKey={result?.retryKey}
                onVerifiedChange={setVerified}
              />

              <button
                type="submit"
                name="intent"
                value="email"
                disabled={submitting || !verified}
                className="button button--dark auth-submit"
              >
                {submitting ? "Please wait…" : "Create account ↗"}
              </button>

              <div className="hb-auth-divider">or</div>

              <button
                type="submit"
                name="intent"
                value="google"
                formNoValidate
                disabled={submitting || !verified}
                className="hb-auth-google"
              >
                <span aria-hidden="true">G</span>
                Continue with Google
              </button>

              <p className="hb-auth-form-note">
                Start free. Your email is used to secure and manage your account.
              </p>
            </Form>
          )}

          <p className="auth-switch">
            Already have an account? <Link to="/login">Log in</Link>
          </p>
        </div>
      </div>

      <aside className="auth-visual">
        <span>HEYBIO BY DIPO LABS</span>
        <div>
          <span className="auth-visual__mark">↗</span>
          <h2>A link that<br />feels like you.</h2>
          <p>Your world. One link.</p>
        </div>
        <span>CREATE · CONNECT · EXPRESS</span>
      </aside>
    </main>
  );
}
