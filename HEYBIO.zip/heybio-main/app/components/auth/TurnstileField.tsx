import { useEffect, useRef, useState } from "react";
import "../../styles/heybio-turnstile.css";

type TurnstileOptions = {
  sitekey: string;
  theme?: "light" | "dark" | "auto";
  size?: "normal" | "flexible" | "compact";
  responseField?: boolean;
  callback?: (token: string) => void;
  "error-callback"?: () => void;
  "expired-callback"?: () => void;
  "timeout-callback"?: () => void;
};

type TurnstileAPI = {
  render: (container: HTMLElement, options: TurnstileOptions) => string;
  reset: (widgetId: string) => void;
  remove: (widgetId: string) => void;
};

declare global {
  interface Window {
    turnstile?: TurnstileAPI;
  }
}

let scriptPromise: Promise<void> | null = null;

function loadScript(): Promise<void> {
  if (window.turnstile) return Promise.resolve();
  if (scriptPromise) return scriptPromise;

  scriptPromise = new Promise<void>((resolve, reject) => {
    const script = document.createElement("script");
    script.src =
      "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
    script.async = true;
    script.defer = true;
    script.onload = () => {
      if (window.turnstile) resolve();
      else reject(new Error("Turnstile did not initialize"));
    };
    script.onerror = () => reject(new Error("Turnstile script failed"));
    document.head.appendChild(script);
  }).catch((error: unknown) => {
    scriptPromise = null;
    throw error;
  });

  return scriptPromise;
}

export default function TurnstileField({
  siteKey,
  retryKey,
  onVerifiedChange,
}: {
  siteKey: string;
  retryKey?: number;
  onVerifiedChange: (verified: boolean) => void;
}) {
  const container = useRef<HTMLDivElement>(null);
  const widgetId = useRef<string | null>(null);
  const [token, setToken] = useState("");
  const [status, setStatus] = useState<"loading" | "ready" | "error">(
    "loading",
  );
  const [reload, setReload] = useState(0);
  const onChangeRef = useRef(onVerifiedChange);
  onChangeRef.current = onVerifiedChange;

  useEffect(() => {
    let active = true;
    setStatus("loading");
    setToken("");
    onChangeRef.current(false);

    loadScript()
      .then(() => {
        if (!active || !container.current || !window.turnstile) return;
        widgetId.current = window.turnstile.render(container.current, {
          sitekey: siteKey,
          theme: "light",
          size: "flexible",
          responseField: false,
          callback(value) {
            if (!active) return;
            setToken(value);
            setStatus("ready");
            onChangeRef.current(true);
          },
          "error-callback"() {
            if (!active) return;
            setToken("");
            setStatus("error");
            onChangeRef.current(false);
          },
          "expired-callback"() {
            if (!active) return;
            setToken("");
            setStatus("error");
            onChangeRef.current(false);
          },
          "timeout-callback"() {
            if (!active) return;
            setToken("");
            setStatus("error");
            onChangeRef.current(false);
          },
        });
      })
      .catch(() => {
        if (active) setStatus("error");
      });

    return () => {
      active = false;
      if (widgetId.current) {
        window.turnstile?.remove(widgetId.current);
        widgetId.current = null;
      }
    };
  }, [siteKey, reload]);

  // Siteverify accepts each token only once. Refresh after a failed POST.
  useEffect(() => {
    if (!retryKey) return;
    setToken("");
    onChangeRef.current(false);
    setStatus("loading");
    if (widgetId.current && window.turnstile) {
      window.turnstile.reset(widgetId.current);
    } else {
      setReload((current) => current + 1);
    }
  }, [retryKey]);

  return (
    <div className="hb-auth-captcha">
      <div className="hb-auth-captcha__heading">Secure your account</div>
      <div ref={container} className="hb-auth-captcha__widget" />
      <input type="hidden" name="cf-turnstile-response" value={token} />
      <div className="hb-auth-captcha__status" aria-live="polite">
        {status === "loading"
          ? "Loading security check…"
          : status === "error"
            ? "Security check needs to be refreshed."
            : token
              ? "Security check complete."
              : "Complete the security check to continue."}
      </div>
      {status === "error" && (
        <button
          className="hb-auth-captcha__retry"
          type="button"
          onClick={() => setReload((count) => count + 1)}
        >
          Retry verification
        </button>
      )}
    </div>
  );
}
