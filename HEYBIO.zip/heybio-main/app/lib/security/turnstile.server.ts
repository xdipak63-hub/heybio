/** Cloudflare Turnstile bindings are available only in Worker request context. */
type Env = {
  TURNSTILE_SITE_KEY?: string;
  TURNSTILE_SECRET_KEY?: string;
};

type WorkerContext = {
  cloudflare?: { env?: Env };
};

type SiteverifyResult = {
  success?: boolean;
  hostname?: string;
  "error-codes"?: string[];
};

export type TurnstileVerdict =
  | { ok: true }
  | { ok: false; status: 400 | 503; message: string };

function bindings(context: unknown): Env {
  const env = (context as WorkerContext | null)?.cloudflare?.env;
  return env ?? {};
}

export function getTurnstileSiteKey(context: unknown): string {
  const siteKey = bindings(context).TURNSTILE_SITE_KEY?.trim();
  if (!siteKey) {
    throw new Response("Security verification is not configured.", {
      status: 503,
      headers: { "Cache-Control": "no-store" },
    });
  }
  return siteKey;
}

export async function verifyTurnstile(
  request: Request,
  context: unknown,
  token: string,
): Promise<TurnstileVerdict> {
  const env = bindings(context);
  const secret = env.TURNSTILE_SECRET_KEY?.trim();
  const siteKey = env.TURNSTILE_SITE_KEY?.trim();

  // Fail closed: never accept a form without both bindings.
  if (!secret || !siteKey) {
    return {
      ok: false,
      status: 503,
      message: "Security verification is temporarily unavailable.",
    };
  }

  if (!token || token.length > 2048) {
    return {
      ok: false,
      status: 400,
      message: "Complete the security check and try again.",
    };
  }

  try {
    const body = new URLSearchParams({
      secret,
      response: token,
    });

    const ip = request.headers.get("CF-Connecting-IP");
    if (ip) body.set("remoteip", ip);

    const response = await fetch(
      "https://challenges.cloudflare.com/turnstile/v0/siteverify",
      {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body,
        signal: AbortSignal.timeout(8000),
      },
    );

    if (!response.ok) throw new Error("Siteverify unavailable");

    const result = (await response.json()) as SiteverifyResult;
    if (result.success !== true) {
      return {
        ok: false,
        status: 400,
        message: "Security check expired or failed. Please try again.",
      };
    }

    // Official test keys are for local development only. Real keys
    // must produce a token for the same hostname as the submitted form.
    const isTestPair =
      siteKey === "1x00000000000000000000AA" &&
      secret === "1x0000000000000000000000000000000AA";

    if (
      !isTestPair &&
      (!result.hostname ||
        result.hostname.toLowerCase() !==
          new URL(request.url).hostname.toLowerCase())
    ) {
      return {
        ok: false,
        status: 400,
        message: "Security verification did not match this website.",
      };
    }

    return { ok: true };
  } catch {
    return {
      ok: false,
      status: 503,
      message: "Verification service unavailable. Please try again shortly.",
    };
  }
}
